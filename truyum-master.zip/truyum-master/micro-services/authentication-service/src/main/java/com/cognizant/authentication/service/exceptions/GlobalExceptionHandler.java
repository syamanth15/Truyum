package com.cognizant.authentication.service.exceptions;

public class GlobalExceptionHandler {

}
