package com.cognizant.truyum.exception;

public class CartEmptyException extends Exception {
	public CartEmptyException() {
		System.out.println("Cart is Emplty");
	}
}
