package com.cognizant.truyum.exception;

public class UserAlreadyExistsException extends Exception {
	public UserAlreadyExistsException() {
		System.out.println("User Alresy Exists");
	}
}
